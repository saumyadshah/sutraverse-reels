#!/usr/bin/env python3
"""SutraVerse sound design: scored music + ambience + story SFX, pre-ducked against the narration.

Saumya (30 Oct): the background sound and music must change with the story, not sit as one
tanpura drone under everything. This builds ONE underscore track that finalize.py mixes with the
narration (no second ducking pass):

  music     modern scenes  -> "warm keys" (soft electric-piano chords + muted pluck pulse + sub pad),
                              minor/"tense" before the verse, major/"warm" after it
            ancient scenes -> tanpura + bansuri-style flute phrases in the same key
            a riser + swell into the turn (first ancient scene), near-silence under the shloka,
            a held tonic chord that resolves under the end card
  ambience  per scene: room | dinner | office | street | night | fire | air | temple | river | rain
  sfx       a soft whoosh on every modern<->ancient change + any story cues listed in sv_script
            (clink, paper, bell, chime, thud, door, notif, gasp-free: no voices are synthesised)

Music source order (CONTENT_STANDARDS §7): a royalty-free track from the repo's music_library/
(with a licence sidecar) when sv_script.sound.music_file names one or --library picks one by mood,
else this original synthesis (royalty-free, no licence needed). Paid music generation is never used.

sv_script.json (all optional; sensible defaults are inferred):
  "sound": {
    "key": "C#",
    "scenes": {"S1": {"world": "modern", "ambience": "dinner", "mood": "tense"},
               "S3": {"world": "ancient", "ambience": "fire"}},
    "sfx": [{"line": "L02", "word": "गिर", "kind": "clink"}, {"at": 23.1, "kind": "bell"}],
    "music_file": "music_library/warm/xyz.mp3"      # optional royalty-free track (licence sidecar required)
  }
Defaults: a scene is "ancient" if any of its lines is a shloka / story_retelling / faithful_paraphrase /
traditional_interpretation with a source_ref, else "modern"; ambience = room (modern) / air (ancient);
mood = tense before the first shloka, warm after it.

Usage: python sound_design.py <project_id> [--seed 7] [--no-music] [--no-ambience] [--library DIR]
Writes assets/audio/underscore.wav (48 kHz stereo), assets/music/bed.wav (music stem, for reference),
artifacts/sound_plan.json (what plays where + provenance). Run after narrate.py, before finalize.py.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _common import load_config, project_dir, read_json, write_json  # noqa: E402

SR = 48000
NOTES = {"C": 0, "C#": 1, "D": 2, "D#": 3, "E": 4, "F": 5, "F#": 6, "G": 7, "G#": 8, "A": 9, "A#": 10, "B": 11}
ANCIENT_CLAIMS = {"story_retelling", "faithful_paraphrase", "traditional_interpretation", "direct_quote"}
AMBIENCES = {"room", "dinner", "office", "street", "night", "fire", "air", "temple", "river", "rain", "none"}
SFX_KINDS = {"whoosh", "clink", "paper", "bell", "chime", "thud", "door", "notif", "riser"}


def midi_hz(n: float) -> float:
    return 440.0 * 2 ** ((n - 69) / 12)


def db(x: float) -> float:
    return 10 ** (x / 20)


# ---------------------------------------------------------------- DSP helpers
def _fft_filter(x: np.ndarray, mag) -> np.ndarray:
    """Zero-phase FFT filter (numpy only; no scipy in the workspace)."""
    n = len(x)
    if n < 4:
        return x
    f = np.fft.rfftfreq(n, 1 / SR)
    return np.fft.irfft(np.fft.rfft(x) * mag(f), n)


def onepole_lp(x: np.ndarray, fc: float) -> np.ndarray:
    return _fft_filter(x, lambda f: 1 / np.sqrt(1 + (f / fc) ** 2))


def bandpass(x: np.ndarray, lo: float, hi: float) -> np.ndarray:
    return _fft_filter(x, lambda f: 1 / np.sqrt(1 + (f / hi) ** 4) / np.sqrt(1 + (lo / np.maximum(f, 1e-3)) ** 4))


def reverb(x: np.ndarray, seconds: float, rng: np.random.Generator) -> np.ndarray:
    n = int(seconds * SR)
    ir = rng.normal(0, 1, n) * np.exp(-np.arange(n) / (SR * seconds / 5))
    ir[0] = 0
    ir /= np.sqrt(np.sum(ir ** 2))
    size = 1 << int(np.ceil(np.log2(len(x) + n)))
    return np.fft.irfft(np.fft.rfft(x, size) * np.fft.rfft(ir, size), size)[: len(x)]


def env_adsr(n: int, a: float, d: float, s: float, r: float) -> np.ndarray:
    t = np.arange(n) / SR
    dur = n / SR
    e = np.minimum(1, t / max(a, 1e-3))
    e = np.where(t > a, s + (1 - s) * np.exp(-(t - a) / max(d, 1e-3)), e)
    e *= np.clip((dur - t) / max(r, 1e-3), 0, 1)
    return e


def add(buf: np.ndarray, sig: np.ndarray, t0: float, pan: float = 0.0, gain: float = 1.0):
    i = int(t0 * SR)
    if i >= len(buf) or i + len(sig) <= 0:
        return
    if i < 0:
        sig, i = sig[-i:], 0
    j = min(len(buf), i + len(sig))
    buf[i:j, 0] += sig[: j - i] * gain * (1 - pan) * 0.5
    buf[i:j, 1] += sig[: j - i] * gain * (1 + pan) * 0.5


# ---------------------------------------------------------------- instruments
def epiano(f: float, dur: float, rng) -> np.ndarray:
    """Soft electric-piano tone: sine + bell partial with fast decay, slow tremolo."""
    n = int(dur * SR)
    t = np.arange(n) / SR
    tone = np.sin(2 * np.pi * f * t) + 0.35 * np.sin(2 * np.pi * 2 * f * t) * np.exp(-t / 0.35) \
        + 0.12 * np.sin(2 * np.pi * 3.98 * f * t) * np.exp(-t / 0.12)
    trem = 1 + 0.08 * np.sin(2 * np.pi * 4.2 * t + rng.uniform(0, 6))
    return tone * trem * env_adsr(n, 0.008, 1.6, 0.35, 0.6)


def pluck(f: float, dur: float) -> np.ndarray:
    """Muted plucked note (Karplus-like with a lowpassed noise burst)."""
    n = int(dur * SR)
    t = np.arange(n) / SR
    return (np.sin(2 * np.pi * f * t) * 0.8 + 0.2 * np.sin(2 * np.pi * 2 * f * t)) * np.exp(-t / 0.18) * np.minimum(1, t / 0.004)


def pad(f: float, dur: float, rng) -> np.ndarray:
    n = int(dur * SR)
    t = np.arange(n) / SR
    s = sum(np.sin(2 * np.pi * f * (1 + d) * t + rng.uniform(0, 6)) for d in (-0.003, 0, 0.0035)) / 3
    s += 0.3 * np.sin(2 * np.pi * 2 * f * t)
    return s * env_adsr(n, 1.2, 2.0, 0.85, 1.4)


def tanpura(f: float, dur: float, rng) -> np.ndarray:
    n = int(dur * SR)
    t = np.arange(n) / SR
    out = np.zeros(n)
    sweep = 1.0 + 6.0 * (1 - np.exp(-t / 1.6))
    for h in range(1, 22):
        amp = (1.0 / h ** 0.9) * np.exp(-((h - sweep) ** 2) / 18.0) + 0.25 / h ** 1.6
        out += amp * np.sin(2 * np.pi * f * h * (1 + rng.normal(0, 0.0007)) * t + rng.uniform(0, 6.28))
    return out * (1 - np.exp(-t / 0.012)) * np.exp(-t / 3.8) * 0.25


def flute(f: float, dur: float, rng) -> np.ndarray:
    """Bansuri-style note: breathy sine with delayed vibrato and a soft glide in."""
    n = int(dur * SR)
    t = np.arange(n) / SR
    vib = 1 + 0.006 * np.sin(2 * np.pi * 5.2 * t) * np.clip((t - 0.35) / 0.4, 0, 1)
    glide = 1 - 0.03 * np.exp(-t / 0.08)
    ph = 2 * np.pi * np.cumsum(f * vib * glide) / SR
    tone = np.sin(ph) + 0.18 * np.sin(2 * ph) + 0.06 * np.sin(3 * ph)
    breath = bandpass(rng.normal(0, 1, n), f * 0.8, f * 3.5) * 0.12
    return (tone + breath) * env_adsr(n, 0.12, 0.8, 0.8, 0.5)


# ---------------------------------------------------------------- music score
def score(total, segs, shloka_spans, turn_t, key, rng, end_card):
    """segs: [(start, end, world, mood)]"""
    out = np.zeros((int((total + 1) * SR), 2))
    root = 48 + NOTES[key] - 12 if NOTES[key] > 6 else 48 + NOTES[key]  # tonic around C3..F#3
    bpm = 72.0
    beat = 60 / bpm
    bar = 4 * beat
    prog = {"tense": [(0, "m"), (-4, "M"), (-9, "M"), (-2, "M")],   # i  VI  III  VII
            "warm": [(0, "M"), (-3, "m"), (5, "M"), (7, "M")],      # I  vi  IV   V
            "calm": [(0, "M"), (5, "M"), (0, "M"), (7, "M")]}
    raga = {"tense": [0, 1, 3, 7, 8, 12], "warm": [0, 2, 4, 7, 9, 12], "calm": [0, 2, 4, 7, 9, 12]}
    for (s, e, world, mood) in segs:
        if world == "modern":
            t = s
            k = 0
            while t < e:
                deg, q = prog[mood][k % 4]
                r = root + deg
                third = 3 if q == "m" else 4
                chord = [r, r + third, r + 7, r + 12 + (2 if mood == "warm" else 0)]
                d = min(bar, e - t + 0.8)
                for i, nn in enumerate(chord):
                    add(out, epiano(midi_hz(nn), d + 1.2, rng), t + i * 0.012, pan=(i - 1.5) * 0.25, gain=0.16)
                add(out, pad(midi_hz(r - 12), d + 1.5, rng), t, gain=0.10)
                # muted pluck pulse on 8ths (light modern texture), softer in tense mood
                for b in range(8):
                    tb = t + b * beat / 2
                    if tb >= e:
                        break
                    nn = chord[[0, 2, 1, 2, 3, 2, 1, 2][b]] + 12
                    add(out, pluck(midi_hz(nn), 0.5), tb, pan=0.35 if b % 2 else -0.35,
                        gain=(0.035 if mood == "tense" else 0.05) * (1.0 if b % 2 == 0 else 0.7))
                t += bar
                k += 1
        else:
            t = s
            cyc = [(root + 7, -0.3), (root + 12, 0.25), (root + 12, 0.3), (root, -0.1)]
            k = 0
            while t < e:
                f, pan = cyc[k % 4]
                add(out, tanpura(midi_hz(f), 5.0, rng), t, pan=pan, gain=0.5)
                t += 1.05 + rng.normal(0, 0.02)
                k += 1
            add(out, pad(midi_hz(root - 12), e - s + 1.5, rng), s, gain=0.08)
            # sparse flute phrases (avoid the shloka; it gets near-silence anyway)
            t = s + 1.2
            sc = raga[mood]
            while t < e - 1.5:
                if any(a - 0.5 <= t <= b for a, b in shloka_spans):
                    t += 1.0
                    continue
                phrase = [sc[int(rng.integers(0, len(sc)))] for _ in range(int(rng.integers(2, 4)))]
                for j, deg in enumerate(phrase):
                    d = float(rng.uniform(0.9, 1.8))
                    add(out, flute(midi_hz(root + 12 + deg), d + 0.4, rng), t, pan=0.15, gain=0.07)
                    t += d
                t += float(rng.uniform(1.5, 3.0))
    # riser into the turn
    if turn_t is not None and turn_t > 2.5:
        n = int(2.2 * SR)
        noise = rng.normal(0, 1, n)
        tt = np.arange(n) / SR
        rise = bandpass(noise, 600, 6000) * (tt / 2.2) ** 2.2 * 0.08
        add(out, rise, turn_t - 2.2, gain=1.0)
    # resolve under the end card: held tonic chord
    ec0 = end_card["start"]
    for i, nn in enumerate([root, root + 4, root + 7, root + 12]):
        add(out, epiano(midi_hz(nn), total - ec0 + 1.5, rng), ec0 - 0.4 + i * 0.03, pan=(i - 1.5) * 0.2, gain=0.14)
    add(out, pad(midi_hz(root - 12), total - ec0 + 2, rng), ec0 - 0.4, gain=0.10)
    rev = np.stack([reverb(out[:, 0], 2.6, rng), reverb(out[:, 1], 2.7, rng)], 1)
    return (0.8 * out + 0.45 * rev)[: int(total * SR)]


# ---------------------------------------------------------------- ambience beds
def ambience(kind: str, n: int, rng) -> np.ndarray:
    t = np.arange(n) / SR
    w = rng.normal(0, 1, n)
    brown = np.cumsum(w)
    brown = onepole_lp(brown - onepole_lp(brown, 0.5), 300)
    brown /= np.max(np.abs(brown)) + 1e-9
    room = brown * 0.5 + onepole_lp(w, 900) * 0.15
    if kind == "none":
        return np.zeros(n)
    if kind == "room":
        return room
    if kind in ("dinner", "office"):
        x = room * 0.8
        # soft distant murmur: band-limited noise with syllabic amplitude modulation (no words)
        mur = bandpass(rng.normal(0, 1, n), 250, 1400)
        am = onepole_lp(np.abs(rng.normal(0, 1, n)), 4)
        x += mur * am / (np.max(am) + 1e-9) * 0.25
        hits = int(n / SR * (0.6 if kind == "dinner" else 2.5))
        for _ in range(hits):
            i = int(rng.uniform(0, n - SR * 0.2))
            if kind == "dinner":  # cutlery ticks
                f = rng.uniform(2500, 4200)
                m = int(0.12 * SR)
                tt = np.arange(m) / SR
                x[i:i + m] += (np.sin(2 * np.pi * f * tt) + 0.5 * np.sin(2 * np.pi * f * 1.47 * tt)) * np.exp(-tt / 0.03) * 0.12
            else:  # keyboard clicks
                m = int(0.02 * SR)
                x[i:i + m] += bandpass(rng.normal(0, 1, m), 1500, 6000) * np.exp(-np.arange(m) / (SR * 0.004)) * 0.25
        return x
    if kind == "street":
        x = onepole_lp(brown, 160) * 1.2 + room * 0.3
        for _ in range(int(n / SR / 9)):  # very distant horn
            i = int(rng.uniform(0, n - SR))
            m = int(rng.uniform(0.25, 0.5) * SR)
            tt = np.arange(m) / SR
            x[i:i + m] += (np.sign(np.sin(2 * np.pi * 410 * tt)) + np.sign(np.sin(2 * np.pi * 520 * tt))) * env_adsr(m, 0.02, 0.2, 0.8, 0.08) * 0.02
        return x
    if kind == "night":
        x = room * 0.35
        for c in range(3):  # crickets: pulsed high chirps, each insect on its own rhythm
            f = rng.uniform(4200, 5200)
            rate = rng.uniform(1.6, 2.6)
            gate = (np.sin(2 * np.pi * rate * t + rng.uniform(0, 6)) > 0.55).astype(float)
            pulse = (np.sin(2 * np.pi * 32 * t) > 0).astype(float)
            x += np.sin(2 * np.pi * f * t) * onepole_lp(gate * pulse, 200) * 0.05
        return x
    if kind == "fire":
        x = onepole_lp(brown, 220) * 0.9
        for _ in range(int(n / SR * 9)):  # crackles
            i = int(rng.uniform(0, n - 400))
            m = int(rng.uniform(40, 260))
            x[i:i + m] += rng.normal(0, 1, m) * np.exp(-np.arange(m) / (m / 4)) * rng.uniform(0.2, 0.7)
        return x
    if kind == "air":
        swell = 0.6 + 0.4 * np.sin(2 * np.pi * t / 11 + rng.uniform(0, 6))
        x = bandpass(w, 200, 1800) * swell * 0.35 + room * 0.2
        for _ in range(int(n / SR / 6)):  # a distant bird now and then
            i = int(rng.uniform(0, n - SR))
            m = int(0.18 * SR)
            tt = np.arange(m) / SR
            f = rng.uniform(2600, 3600) * (1 + 0.15 * np.sin(2 * np.pi * 9 * tt))
            x[i:i + m] += np.sin(2 * np.pi * np.cumsum(f) / SR) * np.sin(np.pi * tt / tt[-1]) * 0.03
        return x
    if kind == "temple":
        x = room * 0.4
        for k in range(int(n / SR / 7) + 1):
            i = int((k * 7 + rng.uniform(0, 3)) * SR)
            if i < n:
                b = bell_tone(rng.uniform(600, 900), 4.0) * 0.08
                x[i:i + len(b)] += b[: max(0, min(len(b), n - i))]
        return x
    if kind == "river":
        return bandpass(w, 300, 3000) * (0.7 + 0.3 * onepole_lp(np.abs(rng.normal(0, 1, n)), 2) * 3) * 0.3 + room * 0.3
    if kind == "rain":
        x = bandpass(w, 800, 9000) * 0.35 + room * 0.3
        for _ in range(int(n / SR * 25)):
            i = int(rng.uniform(0, n - 200))
            x[i:i + 120] += rng.normal(0, 1, 120) * np.exp(-np.arange(120) / 25) * 0.15
        return x
    return room


def bell_tone(f: float, dur: float) -> np.ndarray:
    n = int(dur * SR)
    t = np.arange(n) / SR
    parts = [(1, 1, 1.6), (2.76, 0.5, 0.9), (5.4, 0.25, 0.5), (8.9, 0.12, 0.3)]
    return sum(a * np.sin(2 * np.pi * f * r * t) * np.exp(-t / d) for r, a, d in parts) * np.minimum(1, t / 0.003)


def sfx(kind: str, rng) -> np.ndarray:
    if kind == "whoosh":
        n = int(0.9 * SR)
        t = np.arange(n) / SR
        x = rng.normal(0, 1, n)
        fc = 400 + 3000 * np.sin(np.pi * t / t[-1]) ** 2
        y = np.zeros(n)
        # time-varying band via chunks
        for i in range(0, n, 2048):
            seg = x[i:i + 2048]
            c = float(fc[min(i, n - 1)])
            y[i:i + len(seg)] = bandpass(seg, c * 0.5, c * 1.6)[: len(seg)]
        return y * np.sin(np.pi * t / t[-1]) ** 1.5 * 0.5
    if kind == "paper":
        n = int(0.5 * SR)
        x = bandpass(rng.normal(0, 1, n), 1500, 7000)
        am = onepole_lp(np.abs(rng.normal(0, 1, n)) ** 3, 30)
        return x * am / (np.max(am) + 1e-9) * 0.5
    if kind == "clink":
        n = int(0.7 * SR)
        t = np.arange(n) / SR
        return sum(a * np.sin(2 * np.pi * f * t) * np.exp(-t / d) for f, a, d in
                   [(2350, 1, 0.18), (3420, 0.6, 0.12), (5130, 0.35, 0.07), (6870, 0.2, 0.05)]) * 0.35
    if kind == "bell":
        return bell_tone(720, 3.5) * 0.35
    if kind == "chime":
        m = int(2.6 * SR)
        out = np.zeros(m)
        for i, f in enumerate([1320, 1568, 1760, 2093]):
            b = bell_tone(f, 2.2) * 0.18
            k = int(i * 0.09 * SR)
            out[k:k + len(b)] += b[: m - k]
        return out
    if kind == "thud":
        n = int(0.4 * SR)
        t = np.arange(n) / SR
        return np.sin(2 * np.pi * (70 + 40 * np.exp(-t / 0.05)) * t) * np.exp(-t / 0.09) * 0.7
    if kind == "door":
        n = int(0.6 * SR)
        t = np.arange(n) / SR
        return (np.sin(2 * np.pi * 95 * t) * np.exp(-t / 0.12) + bandpass(rng.normal(0, 1, n), 200, 900) * np.exp(-t / 0.05)) * 0.5
    if kind == "notif":
        n = int(0.35 * SR)
        t = np.arange(n) / SR
        a = np.sin(2 * np.pi * 1760 * t) * np.exp(-t / 0.08)
        b = np.pad(np.sin(2 * np.pi * 2349 * t) * np.exp(-t / 0.1), (int(0.09 * SR), 0))[:n]
        return (a + b) * 0.25
    if kind == "riser":
        n = int(2.0 * SR)
        t = np.arange(n) / SR
        return bandpass(rng.normal(0, 1, n), 500, 6000) * (t / 2.0) ** 2 * 0.3
    raise ValueError(kind)


# ---------------------------------------------------------------- speech envelope
def speech_env(narr: np.ndarray, attack=0.12, release=0.6) -> np.ndarray:
    """0..1 speech activity from the narration itself (smoothed), for automation ducking."""
    hop = 480
    m = len(narr) // hop
    rms = np.sqrt(np.mean(narr[: m * hop].reshape(m, hop) ** 2, axis=1) + 1e-12)
    thr = np.percentile(rms[rms > 1e-5], 35) * 0.6 if np.any(rms > 1e-5) else 1e-3
    act = (rms > thr).astype(float)
    out = np.zeros(m)
    a_up, a_dn = np.exp(-hop / (SR * attack / 3)), np.exp(-hop / (SR * release / 3))
    v = 0.0
    for i, x in enumerate(act):
        v = (a_up * v + (1 - a_up) * x) if x > v else (a_dn * v + (1 - a_dn) * x)
        out[i] = v
    env = np.repeat(out, hop)
    return np.pad(env, (0, max(0, len(narr) - len(env))))[: len(narr)]


def load_audio(path: Path, n: int) -> np.ndarray:
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", str(path), "-ac", "2", "-ar", str(SR), "-f", "f32le", "-"],
                         capture_output=True, check=True).stdout
    x = np.frombuffer(raw, dtype=np.float32).reshape(-1, 2).astype(np.float64)
    if len(x) < n:  # loop a short library track with a crossfade
        reps = int(np.ceil(n / max(1, len(x) - SR))) + 1
        y = np.zeros((reps * len(x), 2))
        pos = 0
        fade = np.linspace(0, 1, SR)[:, None]
        for _ in range(reps):
            seg = x.copy()
            seg[:SR] *= fade
            seg[-SR:] *= fade[::-1]
            y[pos:pos + len(seg)] += seg
            pos += len(seg) - SR
        x = y
    return x[:n]


def rms_db(x):
    return 20 * np.log10(np.sqrt(np.mean(np.square(x))) + 1e-12)


# ---------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("project_id")
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--no-music", action="store_true")
    ap.add_argument("--no-ambience", action="store_true")
    ap.add_argument("--library", help="music_library dir to pick a royalty-free track from (by mood folder)")
    a = ap.parse_args()
    cfg = load_config()
    pdir = project_dir(a.project_id)
    T = read_json(pdir / "artifacts" / "timing.json")
    S = read_json(pdir / "artifacts" / "sv_script.json")
    snd = S.get("sound", {}) or {}
    rng = np.random.default_rng(a.seed)
    total = float(T["total_duration"])
    n = int(total * SR)
    key = snd.get("key") or cfg["music"].get("drone_key", "C#")

    lines = {l["id"]: l for l in S["lines"]}
    order = list(dict.fromkeys(l["scene"] for l in S["lines"]))
    shloka_ids = [l["id"] for l in S["lines"] if l.get("shloka")]
    tl = {l["id"]: l for l in T["lines"]}
    shloka_spans = [(tl[i]["start"] - 0.3, tl[i]["end"] + 0.4) for i in shloka_ids if i in tl]
    first_shloka = min((s for s, _ in shloka_spans), default=total)

    # ---- per-scene plan ----
    plan = []
    for sid in order:
        sc = T["scenes"][sid]
        o = (snd.get("scenes") or {}).get(sid, {})
        sl = [l for l in S["lines"] if l["scene"] == sid]
        ancient = any(l.get("shloka") or (l.get("claim_type") in ANCIENT_CLAIMS and l.get("source_ref")) for l in sl)
        world = o.get("world") or ("ancient" if ancient else "modern")
        mood = o.get("mood") or ("tense" if sc["start"] < first_shloka else "warm")
        amb = o.get("ambience") or ("room" if world == "modern" else "air")
        if amb not in AMBIENCES:
            sys.exit(f"{sid}: unknown ambience '{amb}' (use one of {sorted(AMBIENCES)})")
        plan.append({"scene": sid, "start": sc["start"], "end": sc["end"], "world": world, "mood": mood, "ambience": amb})
    plan[-1]["end"] = max(plan[-1]["end"], T["end_card"]["start"])
    turn = next((p["start"] for p in plan if p["world"] == "ancient"), None)

    # ---- narration + speech envelope ----
    narr = load_audio(pdir / "assets" / "audio" / "narration.wav", n).mean(1)
    sp = speech_env(narr)
    speech_db = rms_db(narr[sp > 0.5]) if np.any(sp > 0.5) else -20.0

    # ---- music ----
    music = np.zeros((n, 2))
    provenance = "none"
    lib_file = snd.get("music_file")
    if not lib_file and a.library:
        mood0 = plan[0]["mood"]
        cands = sorted(Path(a.library).glob(f"{mood0}/*.mp3")) + sorted(Path(a.library).glob("*.mp3"))
        lib_file = str(cands[int(rng.integers(0, len(cands)))]) if cands else None
    if not a.no_music:
        if lib_file:
            lf = Path(lib_file)
            if not lf.is_absolute():
                lf = Path.home() / "sutraverse-reels" / lf
            lic = lf.with_suffix(lf.suffix + ".json")
            if not lic.is_file():
                sys.exit(f"{lf}: a royalty-free track needs a licence sidecar {lic.name} "
                         '({"title","artist","source_url","licence"}). Never use a track without one.')
            music = load_audio(lf, n)
            provenance = {"type": "library", "file": str(lf), **json.loads(lic.read_text(encoding="utf-8"))}
        else:
            music = score(total, [(p["start"], p["end"], p["world"], p["mood"]) for p in plan], shloka_spans, turn, key, rng, T["end_card"])
            provenance = {"type": "original_synthesis", "tool": "sound_design.py", "key": key, "seed": a.seed,
                          "licence": "original, generated locally; royalty-free, no attribution needed"}

    # ---- ambience (crossfaded per scene) ----
    amb = np.zeros((n, 2))
    if not a.no_ambience:
        for p in plan:
            if p["ambience"] == "none":
                continue
            s0 = max(0.0, p["start"] - 0.6)
            s1 = min(total, p["end"] + 0.6)
            m = int((s1 - s0) * SR)
            L, R = ambience(p["ambience"], m, rng), ambience(p["ambience"], m, rng)
            x = np.stack([L * 0.8 + R * 0.2, R * 0.8 + L * 0.2], 1)
            x /= (np.sqrt(np.mean(x ** 2)) + 1e-9)
            f = min(int(0.6 * SR), m // 3)
            x[:f] *= np.linspace(0, 1, f)[:, None]
            x[-f:] *= np.linspace(1, 0, f)[:, None]
            i = int(s0 * SR)
            amb[i:i + len(x)] += x[: n - i]

    # ---- sfx ----
    fx = np.zeros((n, 2))
    cues = []
    for a_, b_ in zip(plan, plan[1:]):
        if a_["world"] != b_["world"]:
            cues.append({"at": b_["start"] - 0.45, "kind": "whoosh", "auto": True})
    for c in snd.get("sfx", []):
        if c.get("kind") not in SFX_KINDS:
            sys.exit(f"sfx kind '{c.get('kind')}' unknown (use one of {sorted(SFX_KINDS)})")
        at = c.get("at")
        if at is None and c.get("line") in tl:
            ws = tl[c["line"]].get("words", [])
            hit = [w for w in ws if w["w"] == c.get("word")] or [w for w in ws if c.get("word", "") and w["w"].startswith(c["word"])]
            at = (hit[0]["start"] if hit else tl[c["line"]]["start"]) + float(c.get("offset", 0))
        if at is not None:
            cues.append({"at": float(at), "kind": c["kind"], "gain_db": c.get("gain_db", 0)})
    for c in cues:
        s = sfx(c["kind"], rng) * db(c.get("gain_db", 0))
        i = int(max(0, c["at"]) * SR)
        j = min(n, i + len(s))
        fx[i:j, 0] += s[: j - i] * 0.9
        fx[i:j, 1] += s[: j - i] * 1.0

    # ---- levels + automation (relative to the measured speech level) ----
    # QA wants speech >= 12 dB above the bed in pauses; we aim for ~15 dB.
    m_pause = speech_db - cfg["music"].get("pause_below_speech_db", 15)
    m_under = speech_db - cfg["music"].get("under_speech_db", 27)
    m_shloka = speech_db - 36
    a_lvl = speech_db - cfg["music"].get("ambience_below_speech_db", 25)
    tvec = np.arange(n) / SR
    if np.any(music):
        ref = music[np.abs(music).sum(1) > 1e-6]
        music *= db(m_pause) / (np.sqrt(np.mean(ref ** 2)) + 1e-9)
        g_db = (m_under - m_pause) * sp  # duck under speech
        for s0, s1 in shloka_spans:  # near-silence under the recitation, soft ramps
            ramp = np.clip(np.minimum((tvec - (s0 - 0.6)) / 0.6, ((s1 + 0.8) - tvec) / 0.8), 0, 1)
            g_db = np.minimum(g_db, (m_shloka - m_pause) * ramp)
        if turn is not None:  # gentle swell into and through the turn
            sw = np.exp(-((tvec - turn) / 1.3) ** 2) * 4.0
            g_db = g_db + sw * (1 - sp)
        music *= db(g_db)[:, None]
    if np.any(amb):
        amb *= db(a_lvl) / (np.sqrt(np.mean(amb[np.abs(amb).sum(1) > 1e-6] ** 2)) + 1e-9)
        amb *= db(-5 * sp)[:, None]
    if np.any(fx):
        fx *= db(speech_db - 8) / (np.max(np.abs(fx)) + 1e-9)  # peaks ~8 dB under speech RMS level

    under = music + amb + fx
    fin, fout = int(0.25 * SR), int(1.8 * SR)
    under[:fin] *= np.linspace(0, 1, fin)[:, None]
    under[-fout:] *= np.linspace(1, 0, fout)[:, None]
    under = np.clip(under, -0.9, 0.9)

    import soundfile as sf

    out = pdir / "assets" / "audio" / "underscore.wav"
    sf.write(str(out), under.astype(np.float32), SR, subtype="PCM_24")
    (pdir / "assets" / "music").mkdir(parents=True, exist_ok=True)
    sf.write(str(pdir / "assets" / "music" / "bed.wav"), np.clip(music, -0.9, 0.9).astype(np.float32), SR, subtype="PCM_16")
    write_json(pdir / "artifacts" / "sound_plan.json", {
        "key": key, "speech_rms_dbfs": round(speech_db, 1), "turn": turn, "shloka_spans": shloka_spans,
        "scenes": plan, "sfx": cues, "music_provenance": provenance,
        "ambience_provenance": "original synthesis (sound_design.py); royalty-free",
        "levels_db_vs_speech": {"music_pauses": -15, "music_under_speech": -27, "music_under_shloka": -36, "ambience": -25},
    })
    worlds = " ".join(f"{p['scene']}:{p['world'][0]}/{p['mood']}/{p['ambience']}" for p in plan)
    print(f"underscore: {out} ({total:.1f}s) music={provenance if isinstance(provenance, str) else provenance['type']}; "
          f"{len(cues)} sfx; scenes {worlds}")


if __name__ == "__main__":
    main()
