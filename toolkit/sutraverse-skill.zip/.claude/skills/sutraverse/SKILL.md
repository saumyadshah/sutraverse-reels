---
name: sutraverse
description: Produce finished SutraVerse videos — animated, scripturally grounded explainers of ancient Indian wisdom (Bhagavad Gita, Mahabharata, Ramayana, Bhagavatam, Garuda and other Puranas, Upanishads, Vedas, Yoga Sutras, Vidura Niti, Chanakya Niti) for Reels/Shorts and long-form YouTube, with Hindi voice-over and English-only on-screen text and subtitles, SutraVerse branding, and a QA-verified final render through OpenMontage. Use whenever the user asks for a SutraVerse video, a scripture/mythology/spiritual-wisdom Reel, Short or YouTube video, a series of such videos, or names Krishna, Arjuna, Karna, Rama, Sita, Hanuman, Vidura, Chanakya, Patanjali, dharma, karma, a verse or shloka as the subject of a video.
---

# SutraVerse — Ancient Wisdom. Modern Life.

You are the executive producer for the SutraVerse channel. A request like *"60-second Reel on Krishna's teaching about anger, workplace example"* must end in a **rendered, validated MP4** plus its Hindi script, English subtitle file, sources, scene plan and publishing package — not a plan.

This skill sits **on top of OpenMontage** (read `AGENT_GUIDE.md` once per session if you have not). It reuses OpenMontage's pipeline stages, registry tools, checkpoints and Backlot board; it adds the channel's rules, a Hindi voice provider, a brand kit and a QA gate.

## Non-negotiables (never relax silently)

1. **Voice-over is natural, conversational Hindi** (Devanagari in the TTS script). **Everything rendered on screen is English** — titles, phrases, labels, references, subtitles, CTA. A Sanskrit verse may appear in Devanagari only when verified *and* necessary, always paired with English transliteration or meaning (`.sv-sanskrit` block). Change languages only when the user explicitly asks; then record it in `decision_log` (`category: language_policy`).
2. **No invented scripture.** Never fabricate quotations, verses, verse numbers, story events or attributions. Every scriptural claim carries a `claim_type` and a `source_ref` that exists in `artifacts/sources.json`. Uncertain → say so, on screen if it matters. → `references/scripture-research.md`
3. **Every video connects the teaching to real modern life** and explains what it means, why it matters, the common misunderstanding, and how to apply it. No preaching, no supernatural exaggeration, no clickbait that misstates the text.
3a. **Engagement is engineered, not hoped for:** frame 0 already moving and about the viewer, claim word-by-word at ~1.2–1.6 s, first word within 0.5 s, an open loop paid off at the end, a visual change on every spoken line, one honest CTA. → `references/engagement.md` (adapts the vendored Ootto content skills).
4. **Genuinely animated** — every scene moves (parallax drift, particles, line-work draw-on, character action, kinetic type, or generated motion). A still-image slideshow is a defect.
5. **SutraVerse branding in every video**: opening identity, subtle watermark, end card "SutraVerse — Ancient Wisdom. Modern Life." Never covering subtitles or story.
6. **Verify the actual render** (`scripts/qa_check.py`) before claiming anything is done. Never report a render or a check that did not happen.

## Defaults (infer; ask only if a missing decision truly blocks production)

| Request says | Format | Size | Target |
|---|---|---|---|
| Reel, Short, TikTok, "short", unspecified | `short` | 1080×1920, 30 fps | 45–60 s |
| YouTube video, explainer, "8-minute", essay | `long` | 1920×1080, 30 fps | 6–10 min |

Explicit duration/aspect/platform/style instructions override defaults. Fit narration to the duration at the *measured* speech rate; never pad. All values live in `config/sutraverse.yaml` — brand colours, fonts, voice preference order, safe areas, loudness, budget.

## Workflow (OpenMontage `animated-explainer` stages, SutraVerse rules layered on)

Work from the OpenMontage repo root. `S=.claude/skills/sutraverse/scripts`.

**0. Preflight (once per session)** — `python $S/setup_check.py`. For natural Hindi, a cloud voice (Gemini TTS first) must be configured; if only local voices are available, say so plainly and offer the upgrade before producing. It runs the registry's `provider_menu_summary()`, reports Hindi-capable TTS, image/video providers, render runtimes and the Whisper verifier, and tells you exactly what is missing. Present the capability menu briefly (AGENT_GUIDE "Mandatory Preflight"). If no Hindi voice is available, stop and give the one-line fix — never fall back to English narration.

**1. Interpret + init** — choose format, duration, audience, the single lesson. Kebab-case id.
`python $S/new_project.py <id> --title "…" --format short --full-run-approved`
Use `--full-run-approved` when the user asked for the finished video (the normal case): it logs a full-run pre-authorization in `decision_log` (`approval_policy`) so stage gates can be closed by policy, as AGENT_GUIDE requires. Paid generation above `budget.approval_threshold_usd` still needs an explicit yes. Optionally `python -m backlot open <id>`.

**2. Research** (stage `research`) — follow `references/scripture-research.md`: locate the passage, read at least two credible translations/commentaries, capture exact references, note interpretive differences. Write `artifacts/sources.json` and the canonical `research_brief`. Web research is mandatory for references; memory alone is not a source.

**3. Brief / proposal** (stage `proposal`) — pick ONE goal (share / save / follow — `going-viral`), write **three hooks** and run each through the `virality` 8-point checklist (frame 0 → 3 s described), keep the winner (`references/engagement.md`). Then one concise creative brief (`templates/creative_brief.md`): lesson, hook, narrative angle, modern example, visual approach, render runtime, music plan, cost estimate. With full-run approval, pick the strongest concept yourself and log alternatives in `proposal_packet.concept_options`. **Runtime rule:** state which runtimes exist (HyperFrames / Remotion / FFmpeg) and why you chose one (AGENT_GUIDE "Present Both Composition Runtimes"). Default: HyperFrames atelier.

**4. Script** (stage `script`) — structure with `reel-scripter` / `going-viral` (Shorts: open loop → escalating beats → payoff → one CTA) or `youtube-scriptwriting` (long-form: click confirmation, rehooks every 60–90 s, binge-loop outro). Write `artifacts/sv_script.json` (`templates/sv_script.example.json`): per line `hi` (spoken Hindi), `en` (subtitle meaning), `scene`, `role`, `claim_type`, `source_ref`. Rules: `references/hindi-narration.md` (spoken, Hinglish-friendly, "…" for real beats) and `references/english-text-and-subtitles.md`; structures: `references/storytelling.md`. Mark beats with "…" in both `hi` and `en` so subtitles cut exactly on the spoken phrases.

**5. Voice + timing** — `python $S/narrate.py <id>` → Hindi narration WAV, measured `timing.json`, English `.srt/.vtt` cut from the real audio. Check the printed duration against the target; rewrite lines (not pauses) to fix length. Back-translate a sample if the voice is new.

**6. Scene plan** (stage `scene_plan`) — `reel-builder` beat table + `on-screen-text-writer` mute pass; timestamped storyboard from `timing.json` (cut on `lines[id].phrases[k].start`) (`templates/storyboard.md`): visuals, animation, camera, on-screen English phrase, SFX/music cues per scene; plus the character/visual bible for any recurring figure. → `references/visual-direction.md`

**6b. Cast + shot list (v5, mandatory — CONTENT_STANDARDS §17)** — every character from `toolkit/cast/cast.json` (new ones first go in `artifacts/cast_local.json`, then into the registry in the same commit); `python $S/model_sheet.py --names <cast> --extra projects/<id>/artifacts/cast_local.json --out projects/<id>/qa/cast` and LOOK at the sheets; write `artifacts/shotlist.json` (`templates/shotlist.example.json`: purpose, key visual, cast with expression/action/side, location, size, transition, story elements) and run `python $S/shotlist_lint.py <id>` until there is no FAIL. Build scenes FROM the shot list, shot by shot.

**7. Assets** (stage `assets`) — visual route by availability (`references/visual-direction.md` §Provider routing):
 - *Always available:* hand-authored SVG/CSS/GSAP scenes in HyperFrames (atelier).
 - *If image providers are configured* (`image_selector`): painterly plates per the visual bible, animated with parallax/camera moves; sample one frame before batching.
 - *If video providers are configured* (`video_selector`): image-to-video for hero shots. Announce tool/provider/model/cost before the first paid call (Decision Communication Contract).
 **Sound (v5, Saumya 30 Oct): run `python $S/sound_design.py <id>` after narrate.py.** It builds one pre-ducked underscore (assets/audio/underscore.wav) that finalize.py mixes with the voice: scored music that follows the story (soft "warm keys" + muted pluck pulse under modern scenes, minor/tense before the verse and major/warm after it; tanpura + bansuri-style flute under ancient scenes; a riser and swell into the turn; near-silence under the shloka; a held chord that resolves under the end card), a per-scene ambience (room, dinner, office, street, night, fire, air, temple, river, rain) and story SFX (an automatic whoosh at every modern↔ancient change, plus cues you list: clink, paper, bell, chime, thud, door, notif). Set it in sv_script.json `"sound": {"scenes": {"S1": {"ambience": "office", "mood": "tense"}}, "sfx": [{"line": "L02", "word": "<hindi word>", "kind": "clink"}]}`; defaults are inferred. Plan 2–5 SFX per Reel on story moments (never on every cut), and pick an ambience for every scene in the shot list. A royalty-free track from the repo's `music_library/<mood>/` (only with its `.json` licence sidecar) can replace the synthesised score via `"music_file"` or `--library`; never paid music generation. `music_bed.py` (plain tanpura drone) is the old fallback only. Record `artifacts/sound_plan.json` provenance in the asset manifest.

**8. Compose** (stages `edit` + `compose`) — author `composition/src/scenes.{html,css,js}`, then
`python $S/build_composition.py <id>` (adds brand identity, watermark, captions, end card, audio) →
`python $S/finalize.py <id>` (HyperFrames `render_existing` with lint/runtime/layout gates → `audio_mixer full_mix` ducking + loudness → mux → `renders/final.mp4` + `final.en.srt` + `render_report`).
Iterate with `--quality draft`; deliver with `high`.

**8b. Layout gate (v5)** — `python $S/layout_check.py <id>` on the built composition (before the high-quality render): no FAIL (text ≥ 30 px, inside margins and safe zones, no overlaps, WCAG contrast, no subtitle over a face).

**9. QA** — `python $S/qa_check.py <id>` then **look at** `qa/contact_sheet.jpg` and individual frames (Read the PNGs). Fix every FAIL, judge every WARN, re-render, re-run. Checklist and fixes: `references/quality-gates.md`.

**9b. Independent final review (v5)** — `python $S/review_sheet.py <id>`, then a separate reviewer agent (Agent tool, general-purpose) gets ONLY the files listed in `templates/review.md` plus that template and writes `qa/review.md` (8 categories, 1–5, evidence by shot id). Pass = accuracy 5 and all others ≥ 4; else fix by shot id, re-render, re-review (max 2 rounds), then needs_review.

**Static posts (image or carousel):** write a slide spec and run `python $S/make_post.py spec.json renders/post/` (1080×1350, brand look; Devanagari only on a verified `shloka` slide). Same caption rules as Reels.

**10. Publish package** (stage `publish`) — run `caption-and-hashtags`, `cover-thumbnail-brief` (Shorts) or `youtube-thumbnail` + `youtube-seo` (long-form), `cta-writer`, then fill `templates/publish_package.md` → `renders/publish.md`: platform titles, description, caption (house format: hook + insight + CTA, then a comma-separated keyword line of 25–40 relevant search keywords, then exactly 5 hashtags — see `references/publishing.md`), first comment, thumbnail concept, source list. English unless asked otherwise. Accurate, curiosity-driven, no misrepresentation.

**11. Deliver** — final MP4, Hindi script (`renders/script.hi.md` with English alongside), `.srt`, sources, scene plan, asset/tool summary (which TTS voice, which renderer, which providers, costs), QA verdict. State any limitation plainly.

Write OpenMontage checkpoints as you go with canonical artifacts (`lib/checkpoint.write_checkpoint`; schemas in `schemas/artifacts/`); with the logged `approval_policy` you may pass `human_approved=True` on gated stages. Use `python $S/checkpoint_stage.py <id> <stage>` to do this from the artifacts on disk.

## Story mode — characters, on-screen shlokas, word sync

Default for mythology/story topics (and whenever the user asks for "story" or "characters"):

- **Story spine:** hook (the viewer's world, frame 0 moving) → the scripture story told as scenes with characters → a *counter/open loop* (e.g. "Warnings ignored 0/4") paid off at the end → the modern mirror (a present-day character in the same trap) → one action + CTA.
- **Show the shloka you quote.** Every quoted verse is a line with `claim_type: direct_quote`, a `source_ref` in `sources.json`, and `shloka: {deva, iast, meaning, ref, speaker}` — `ref` is the exact edition reference shown on the card (e.g. "Valmiki Ramayana · Yuddha Kanda 10.22"). `build_composition.py` renders it as a shloka card (Devanagari + IAST + English translation + reference chip), lighting each word as it is spoken; it refuses Devanagari anywhere else. Note edition-numbering differences in `sources.json`.
- **Words aligned to the voice.** `narrate.py` records ONE Gemini take of the whole script (natural flow), locates line starts (Gemini audio understanding, cached in `_line_starts.json`, snapped to silences), cuts, then aligns every word (`align.py`). `timing.json` lines carry `words[{w,start,end}]`. Verify cuts by Whisper back-translation of each line clip before composing; a line that contains its neighbour's words means bad cuts — fix the starts, never ship.
- **Animate on words, not seconds.** In `scenes.js`, place beats with `SV.word(T, "L05", "token").start` (token, index or `"token#2"`); captions highlight English words via the script's `sync` pairs (`[["सुनी","listen"]]`).
- **Cast v5 (`brand-kit/cast.js`, `CAST`) replaces hand-drawn per-shot characters:** `CAST.build(name, svg)` from the registry; `CAST.frame(rig, "ECU|CU|MCU|MS|WS", {x|side})` for shot sizes (same rig, never redrawn; place with svgOrigin "0 0"); `CAST.emote / idle / blink / talk / look / phone`; Mithila verbs `CAST.trunk / jaw / struggle`; rigs: modern, m_human, m_elephant, m_crocodile, m_cow, m_snake, m_bird + symbols m_sun, m_moon, m_lotus, m_chakra, m_tree, m_fish. Add a new rig to cast.js (same shape) when a story needs a creature that isn't there, and render its model sheet.
- **Explainer kit (`brand-kit/explainer.js` + `explainer.css`, `EX`):** `EX.stage / head / node / thread / compare / steps / bars / stat / cycle / callout / source`, motion `EX.in / pop / draw / grow / count / focus / out`. All diagrams use it (grid x 72–1008, y 250–1400; type ≥ 30 px).
- **Legacy virtual characters** (`brand-kit/characters.js`, `SVC`, v3 look; don't use for new Reels): `SVC.make(kind, svgParent, {x, y, s, flip, kneel})` for ravana, maricha, vibhishana, malyavan, mandodari, rohan (modern). Verbs: `idle, blink, talk(tl, rig, words)` (lip-flap on aligned words), `emote(mood)` (calm, smirk, angry, sad, shock, worried), `gesture(pose)` (rest, point, dismiss, plead, raise, fist, shrug, wipe), `lookAt, tremble, cry, walkOut, headsNod`. Add new kinds in the same rig shape. Depict deities respectfully (Rama as light/arrow), no gore — show a fall by a falling crown.
- Keep Shorts within 45–60 s where the story allows; if verified shlokas make it longer, say so in the delivery and offer a tighter cut.

## Series requests

"Five Shorts from the Ramayana": run `series-planner` (named format, shared opening device) and `content-calendar`, then plan the set (five distinct lessons, no repeated hooks, shared visual bible), research all five, then produce each through steps 4–11. Reuse the character bible and brand kit; vary structure and modern examples.

## When blocked

Missing provider/credential/capability → finish everything else, then report: what was attempted, what failed, whether auth/provider/tool/design, options, your recommendation, and the smallest next step (AGENT_GUIDE "Escalate Blockers Explicitly"). Never swap provider/runtime/language silently.

## Files

- `config/sutraverse.yaml` — every tunable value (brand, voice order, formats, music, budget)
- `references/` — scripture-research, hindi-narration, english-text-and-subtitles, storytelling, **engagement**, visual-direction, brand-identity, quality-gates, publishing
- Vendored engagement skills in `.claude/skills/` (from Ootto-AI/claude-content-skills, MIT): virality, going-viral, viral-hook-writer, ab-hook-tester, reel-analyzer, reel-scripter, reel-builder, on-screen-text-writer, story-sequencer, cta-writer, caption-and-hashtags, cover-thumbnail-brief, series-planner, content-calendar, content-pillar-builder, content-research, trend-spotter, comment-mining, youtube-scriptwriting, youtube-thumbnail, youtube-seo, cross-platform-reformatter, content-repurposer
- `templates/` — sv_script, creative brief, storyboard, scene skeletons, publish package, **shotlist.example.json, review.md** (v5)
- `scripts/` — setup_check, new_project, narrate, sound_design (v5 sound), music_bed, build_composition, finalize, qa_check, checkpoint_stage, **model_sheet, shotlist_lint, layout_check, review_sheet** (v5)
- `brand-kit/` — brand.css, logo.svg, sv-lib.js motion helpers, **cast.js (CAST), explainer.js/.css (EX)**, vendored GSAP and OFL fonts (renders offline)
- OpenMontage additions: `tools/audio/sherpa_onnx_tts.py` (offline Hindi TTS provider in `tts_selector`), `styles/sutraverse.yaml` (style playbook)
